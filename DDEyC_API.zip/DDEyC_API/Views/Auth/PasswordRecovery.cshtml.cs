using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DDEyC_API.Views.Auth
{
    public class PasswordRecoveryModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
