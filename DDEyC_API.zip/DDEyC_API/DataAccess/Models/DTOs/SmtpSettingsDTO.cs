﻿namespace DDEyC_API.DataAccess.Models.DTOs
{
    public class SmtpSettingsDTO
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
